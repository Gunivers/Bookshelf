Ce dossier contient les répertoires des membres participant au développement de cette librairie.

Ainsi, les fonctions que vous trouverez plus bas ne repectent pas forcément les conventions de la librairie et elles ne disposent d'aucun manuel d'utilisation.

Si vous souhaitez tout de même utiliser ces fonctions, vous pouvez demander de l'aide auprès du membre correspondant.
