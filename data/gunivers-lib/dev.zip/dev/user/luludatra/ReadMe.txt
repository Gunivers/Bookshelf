﻿DOSSIER USER
@Luludatra

FB - Find Block
RS - Rotation Structure